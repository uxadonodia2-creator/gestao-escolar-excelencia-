# Vitrine — Pós-Graduação em Gestão Escolar de Excelência

Landing page estática para divulgação da oferta.

Arquivos: `index.html`, `style.css`, `script.js`.

Publicação: envie os três arquivos para um repositório GitHub e ative GitHub Pages em Settings → Pages → Deploy from a branch → main → /(root).

O botão de matrícula usa o checkout informado para a oferta. Preço, datas e disponibilidade podem mudar; confira no checkout antes de publicar.